package com.planifscolaire.utilisateurs.exception;

import org.springframework.http.HttpStatus;

public class ApiException extends RuntimeException {
    private final HttpStatus status;

    public ApiException(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public static ApiException missing(String message) {
        return new RessourceIntrouvableException(message);
    }

    public static ApiException conflict(String message) {
        return new ConflitMetierException(message);
    }
}
